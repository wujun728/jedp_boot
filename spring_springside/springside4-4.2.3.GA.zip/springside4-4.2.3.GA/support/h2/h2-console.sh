#!/bin/bash

echo "[INFO] Open a H2 web console."

mvn exec:java
