1.catalina.bat/sh:  JAVA_OPTS add  JVM performance tunning options.
2.server.xml:
  a.connector/thread pool tunning.
  b.gzip compression turn on.
  c.database connection pool setting.
  d.load balance setting.
  e.keeplive setting
  f.useBodyEncodingForURI="true" setting
3.context.xml:database connection pool setting.