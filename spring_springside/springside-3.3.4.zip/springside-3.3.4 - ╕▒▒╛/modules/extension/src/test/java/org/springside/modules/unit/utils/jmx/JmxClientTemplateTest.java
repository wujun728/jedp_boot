package org.springside.modules.unit.utils.jmx;

import org.junit.Ignore;

@Ignore("see test in showcase example.")
public class JmxClientTemplateTest {
}
