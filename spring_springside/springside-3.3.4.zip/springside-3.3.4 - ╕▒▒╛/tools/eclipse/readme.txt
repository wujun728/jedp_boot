Please see the wiki:
http://wiki.springside.org.cn/display/SpringSide3/Eclipse